import { useState, useEffect } from 'react';
import { authenticateUser, isAuthenticated } from '../Lib/auth';
import Navbar from '../components/Navbar';
import { useRouter } from 'next/router';
import Link from 'next/link';

export default function LoginPage() {
  const [userName, setUserName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated()) {
      router.push('/admin');
    }
  }, [router]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Basic client-side validation
    if (!userName.trim()) {
      setError('Username is required');
      setLoading(false);
      return;
    }

    if (!password) {
      setError('Password is required');
      setLoading(false);
      return;
    }

    try {
      console.log('Submitting login form...');
      console.log('API URL:', process.env.NEXT_PUBLIC_API_URL);
      
      const result = await authenticateUser(userName.trim(), password);
      
      console.log('Login result:', result);
      
      if (result.success) {
        console.log('Login successful, redirecting to admin...');
        // Small delay to ensure token is set before navigation
        setTimeout(() => {
          router.push('/admin');
        }, 100);
      } else {
        setError(result.message || 'Login failed. Please check your credentials.');
      }
    } catch (err) {
      console.error('Login error:', err);
      
      // Handle specific error messages
      let errorMessage = 'Login failed. Please try again.';
      
      if (err.message) {
        if (err.message.includes('404')) {
          errorMessage = 'Login endpoint not found. Please check your API configuration.';
        } else if (err.message.includes('401') || err.message.toLowerCase().includes('unauthorized') || err.message.toLowerCase().includes('authentication failed')) {
          errorMessage = 'Invalid username or password.';
        } else if (err.message.includes('500')) {
          errorMessage = 'Server error. Please try again later.';
        } else if (err.message.includes('Failed to fetch') || err.message.includes('NetworkError')) {
          errorMessage = 'Unable to connect to server. Please check your internet connection.';
        } else if (err.message.includes('API URL is not configured')) {
          errorMessage = 'Configuration error. Please contact the administrator.';
        } else {
          errorMessage = err.message;
        }
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      {/* Adjusted top padding: 84px = 1.5x navbar height (56px) */}
      <div className="max-w-md mx-auto p-4 md:p-8 pt-[84px]">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-8">
          <div className="mb-8 text-center">
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">Admin Login</h1>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              This page is only for authorized users
            </p>
            {process.env.NODE_ENV === 'development' && (
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                API URL: {process.env.NEXT_PUBLIC_API_URL || 'Not configured'}
              </p>
            )}
          </div>
          
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6 dark:bg-red-900/30 dark:border-red-800 dark:text-red-200">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="mb-6">
            <div className="mb-4">
              <label htmlFor="userName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Username
              </label>
              <input
                id="userName"
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:border-gray-600 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
                placeholder="Enter admin username"
                required
                disabled={loading}
              />
            </div>
            <div className="mb-6">
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:border-gray-600 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
                placeholder="Enter admin password"
                required
                disabled={loading}
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Logging in...' : 'Login'}
            </button>
          </form>
          
          <div className="text-center border-t border-gray-200 dark:border-gray-700 pt-6">
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              This page is for site administration only.
            </p>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              If you're not authorized to access this page, please return to the main site.
            </p>
            <Link 
              href="/" 
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600"
            >
              Return to Main Site
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}