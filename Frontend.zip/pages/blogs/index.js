// pages/admin/index.js
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { getAllSubmissions, getBlogs, getProjects } from '../../Lib/userdata';
import { isAuthenticated, readToken } from '../../Lib/auth';
import Navbar from '../../components/Navbar';
import { useRouter } from 'next/router';

export default function AdminDashboard() {
  const [submissions, setSubmissions] = useState([]);
  const [blogs, setBlogs] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const router = useRouter();

  useEffect(() => {
    // Check authentication status
    const checkAuth = async () => {
      const authenticated = isAuthenticated();
      if (!authenticated) {
        router.push('/login');
      } else {
        setAuthChecked(true);
      }
    };

    checkAuth();
  }, [router]);

  useEffect(() => {
    if (!authChecked) return;

    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Get token details to verify expiration
        const tokenData = readToken();
        if (!tokenData) {
          router.push('/login');
          return;
        }
        
        // Fetch all data in parallel
        const [submissionsData, blogsData, projectsData] = await Promise.all([
          getAllSubmissions().catch(e => ({ error: e.message })),
          getBlogs(1, 5, false).catch(e => ({ error: e.message })),
          getProjects(1, 5).catch(e => ({ error: e.message }))
        ]);
        
        // Handle submissions
        if (submissionsData.error) {
          console.error('Error fetching submissions:', submissionsData.error);
        } else {
          setSubmissions(Array.isArray(submissionsData) ? submissionsData : 
                        submissionsData.data || []);
        }
        
        // Handle blogs
        if (blogsData.error) {
          console.error('Error fetching blogs:', blogsData.error);
        } else {
          setBlogs(blogsData.blogs || []);
        }
        
        // Handle projects
        if (projectsData.error) {
          console.error('Error fetching projects:', projectsData.error);
        } else {
          setProjects(projectsData.projects || []);
        }
        
      } catch (error) {
        console.error('Error fetching data:', error);
        setError(error.message || 'Failed to load data. Please try again.');
        
        // If unauthorized, redirect to login
        if (error.message.includes('401') || error.message.includes('Unauthorized')) {
          router.push('/login');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [authChecked, router]);

  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch (e) {
      return 'Invalid date';
    }
  };

  // If auth hasn't been checked yet, show nothing
  if (!authChecked) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <Navbar />
        <div className="max-w-6xl mx-auto p-8 pt-28">
          {/* Empty state while checking auth */}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      
      <div className="max-w-6xl mx-auto p-4 md:p-8 pt-28">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-8">Admin Dashboard</h1>
        
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6 dark:bg-red-900/30 dark:border-red-800 dark:text-red-200">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* Blog Management Card */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white">Blog Posts</h2>
              <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
                {blogs.length} {blogs.length === 1 ? 'Post' : 'Posts'}
              </span>
            </div>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Manage your blog content, create new posts, and edit existing ones.
            </p>
            <div className="mt-4">
              <Link href="/admin/blogs" className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 font-medium text-sm">
                Manage Blogs →
              </Link>
            </div>
            
            {blogs.length > 0 && (
              <div className="mt-4 border-t border-gray-200 dark:border-gray-700 pt-4">
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Recent Posts</h3>
                <ul className="space-y-2">
                  {blogs.slice(0, 3).map(blog => (
                    <li key={blog._id} className="text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400 truncate">{blog.title}</span>
                        <span className="text-gray-500 dark:text-gray-500 text-xs">{formatDate(blog.createdAt)}</span>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Project Management Card */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white">Projects</h2>
              <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">
                {projects.length} {projects.length === 1 ? 'Project' : 'Projects'}
              </span>
            </div>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Showcase your work by adding and managing your projects.
            </p>
            <div className="mt-4">
              <Link href="/admin/projects" className="text-green-600 hover:text-green-800 dark:text-green-400 dark:hover:text-green-300 font-medium text-sm">
                Manage Projects →
              </Link>
            </div>
          </div>

          {/* Contact Submissions Card */}
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white">Contact Submissions</h2>
              <span className="bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded dark:bg-purple-900 dark:text-purple-300">
                {submissions.length} {submissions.length === 1 ? 'Submission' : 'Submissions'}
              </span>
            </div>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Review messages sent through your contact form.
            </p>
            <div className="mt-4">
              <Link href="/admin/submissions" className="text-purple-600 hover:text-purple-800 dark:text-purple-400 dark:hover:text-purple-300 font-medium text-sm">
                View Submissions →
              </Link>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/admin/blogs/create" className="bg-blue-600 hover:bg-blue-700 text-white text-center py-3 px-4 rounded-lg transition-colors">
              New Blog Post
            </Link>
            <Link href="/admin/projects/create" className="bg-green-600 hover:bg-green-700 text-white text-center py-3 px-4 rounded-lg transition-colors">
              New Project
            </Link>
            <Link href="/blogs" className="bg-gray-600 hover:bg-gray-700 text-white text-center py-3 px-4 rounded-lg transition-colors">
              View Live Blog
            </Link>
            <Link href="/" className="bg-indigo-600 hover:bg-indigo-700 text-white text-center py-3 px-4 rounded-lg transition-colors">
              Visit Site
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}