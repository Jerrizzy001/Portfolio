// pages/blogs/[id].js
import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';
import { getBlogById } from '../../Lib/userdata';
import Navbar from '../../components/Navbar';

export default function BlogPost() {
  const router = useRouter();
  const { id } = router.query;
  const [blog, setBlog] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!id) return;

    const fetchBlog = async () => {
      try {
        const response = await getBlogById(id);
        setBlog(response.blog);
      } catch (err) {
        setError('Blog not found');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchBlog();
  }, [id]);

  if (loading) return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <div className="pt-20 flex justify-center items-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    </div>
  );

  if (error) return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <div className="pt-20 flex justify-center items-center">
        <div className="text-red-500">{error}</div>
      </div>
    </div>
  );

  if (!blog) return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <div className="pt-20 flex justify-center items-center">
        <div>Blog not found</div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <article className="max-w-4xl mx-auto px-4 py-8 pt-20">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            {blog.title}
          </h1>
          <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
            <span>{new Date(blog.createdAt).toLocaleDateString()}</span>
          </div>
        </header>
        
        <div 
          className="prose dark:prose-invert max-w-none"
          dangerouslySetInnerHTML={{ __html: blog.content }}
        />
      </article>
    </div>
  );
}