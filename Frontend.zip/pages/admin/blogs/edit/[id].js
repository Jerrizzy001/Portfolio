// pages/admin/blogs/edit/[id].js
import { useRouter } from 'next/router';
import BlogEditor from '../../../../components/BlogEditor';
import AdminLayout from '../../../../components/AdminLayout';

export default function EditBlogPage() {
  const router = useRouter();
  const { id } = router.query;

  return (
    <AdminLayout>
      <BlogEditor blogId={id} />
    </AdminLayout>
  );
}