// pages/admin/blogs/create.js
import BlogEditor from '../../../components/BlogEditor';
import AdminLayout from '../../../components/AdminLayout';

export default function CreateBlogPage() {
  return (
    <AdminLayout>
      <BlogEditor />
    </AdminLayout>
  );
}