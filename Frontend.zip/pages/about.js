import { motion } from 'framer-motion';
import Navbar from '../components/Navbar';

export default function About() {
  return (
    <div className="min-h-screen bg-white text-black dark:bg-black dark:text-white transition-colors duration-300">
      <Navbar />

      <section className="pt-28 px-6 max-w-4xl mx-auto">
        <motion.h1
          className="text-4xl md:text-5xl font-bold mb-6 text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          About Me
        </motion.h1>

        <motion.p
          className="text-lg leading-relaxed mb-6 text-gray-700 dark:text-gray-300"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          Hi, I’m <strong>Jerry Nwachi</strong>, a passionate software development student based in Toronto.
          I’m currently studying towards a Bachelor’s in Software Development at Seneca Polytechnic, and
          I bring a strong foundation in full-stack development, cloud platforms, and databases.
        </motion.p>

        <motion.p
          className="text-lg leading-relaxed mb-6 text-gray-700 dark:text-gray-300"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          I’ve worked on dynamic web apps using <strong>Next.js, React, Node.js, and Django</strong>.
          I’m comfortable building everything from reusable components to backend logic, REST APIs, and
          database integration. I believe in writing clean, scalable code and continuously improving through feedback and collaboration.
        </motion.p>

        <motion.p
          className="text-lg leading-relaxed mb-6 text-gray-700 dark:text-gray-300"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
        >
          Outside of my studies, I’ve worked as a <strong>Student Ambassador at Seneca</strong> and a
          <strong> Facility Attendant at the City of Markham</strong>, where I developed strong communication,
          time management, and technical troubleshooting skills.
        </motion.p>

        <motion.p
          className="text-lg leading-relaxed mb-6 text-gray-700 dark:text-gray-300"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
        >
          I’m currently open to <strong>internship and entry-level opportunities</strong> where I can
          contribute to a team, learn from experienced developers, and grow my skills in real-world projects.
        </motion.p>

        <motion.div
          className="mt-10 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.1 }}
        >
          <a
            href="connect"
            className="inline-block px-6 py-3 bg-black text-white dark:bg-white dark:text-black rounded-full font-semibold hover:opacity-80 transition"
          >
            Let’s Connect
          </a>
        </motion.div>
      </section>
    </div>
  );
}
