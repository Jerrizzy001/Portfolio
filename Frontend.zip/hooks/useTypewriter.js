import { useEffect, useState } from 'react';

export default function useTypewriter(text, delay = 300) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(false);
    const timer = setTimeout(() => {
      setVisible(true);
    }, delay);

    return () => clearTimeout(timer);
  }, [text, delay]);

  return visible ? text : '';
}
