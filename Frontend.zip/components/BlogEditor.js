// components/BlogEditor.js
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { createBlog, updateBlog, getBlogById } from '../Lib/userdata';
import { isAuthenticated, isAdmin } from '../Lib/auth';

export default function BlogEditor({ blogId = null }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [blogData, setBlogData] = useState({
    title: '',
    content: '',
    published: false,
    featuredImage: null
  });

  // Check if user is authenticated and admin
  useEffect(() => {
    if (!isAuthenticated() || !isAdmin()) {
      router.push('/login');
    }
  }, [router]);

  // Fetch blog data if editing
  useEffect(() => {
    if (blogId) {
      const fetchBlog = async () => {
        try {
          const response = await getBlogById(blogId);
          setBlogData({
            title: response.blog.title,
            content: response.blog.content,
            published: response.blog.published,
            featuredImage: null
          });
        } catch (err) {
          setError('Failed to load blog');
          console.error(err);
        }
      };
      fetchBlog();
    }
  }, [blogId]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setBlogData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleImageChange = (e) => {
    setBlogData(prev => ({
      ...prev,
      featuredImage: e.target.files[0]
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      if (blogId) {
        // Update existing blog
        await updateBlog(blogId, blogData, blogData.featuredImage);
        setSuccess('Blog updated successfully!');
      } else {
        // Create new blog
        await createBlog(blogData, blogData.featuredImage);
        setSuccess('Blog created successfully!');
      }
      
      // Redirect to blogs list after a short delay
      setTimeout(() => {
        router.push('/admin/blogs');
      }, 1500);
    } catch (err) {
      setError(err.message || 'Failed to save blog');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">
        {blogId ? 'Edit Blog Post' : 'Create New Blog Post'}
      </h1>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {success}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
            Title
          </label>
          <input
            type="text"
            id="title"
            name="title"
            value={blogData.title}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        
        <div>
          <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-1">
            Content
          </label>
          <textarea
            id="content"
            name="content"
            value={blogData.content}
            onChange={handleChange}
            rows={15}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        
        <div>
          <label htmlFor="featuredImage" className="block text-sm font-medium text-gray-700 mb-1">
            Featured Image
          </label>
          <input
            type="file"
            id="featuredImage"
            name="featuredImage"
            onChange={handleImageChange}
            accept="image/*"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        
        <div className="flex items-center">
          <input
            type="checkbox"
            id="published"
            name="published"
            checked={blogData.published}
            onChange={handleChange}
            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
          />
          <label htmlFor="published" className="ml-2 block text-sm text-gray-900">
            Publish immediately
          </label>
        </div>
        
        <div className="flex space-x-4">
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {loading ? 'Saving...' : (blogId ? 'Update Blog' : 'Create Blog')}
          </button>
          
          <button
            type="button"
            onClick={() => router.push('/admin/blogs')}
            className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}