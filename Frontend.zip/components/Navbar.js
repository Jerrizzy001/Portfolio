import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { FaBars, FaTimes, FaCaretDown, FaUser, FaSignOutAlt, FaBlog, FaProjectDiagram } from 'react-icons/fa';
import { useTheme } from 'next-themes';
import { MdDarkMode, MdLightMode } from 'react-icons/md';
import { isAuthenticated, isAdmin, logout, onAuthChange, getCurrentUser } from '../Lib/auth';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [adminDropdown, setAdminDropdown] = useState(false);
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [auth, setAuth] = useState(false);
  const [admin, setAdmin] = useState(false);
  const [user, setUser] = useState(null);
  const router = useRouter();

  // Update auth state
  const updateAuthState = () => {
    const isAuth = isAuthenticated();
    const isAdminUser = isAdmin();
    const currentUser = getCurrentUser();
    
    setAuth(isAuth);
    setAdmin(isAdminUser);
    setUser(currentUser);
  };

  useEffect(() => {
    setMounted(true);
    updateAuthState();
    
    // Listen for auth changes across tabs and components
    const cleanup = onAuthChange(updateAuthState);
    
    return cleanup;
  }, []);

  const toggleMenu = () => setIsOpen(!isOpen);
  const closeMenu = () => {
    setIsOpen(false);
    setAdminDropdown(false);
  };

  const handleLogout = async () => {
    try {
      logout();
      updateAuthState();
      closeMenu();
      
      // Redirect to home if on admin pages
      if (router.pathname.startsWith('/admin')) {
        router.push('/');
      }
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const toggleAdminDropdown = () => {
    setAdminDropdown(!adminDropdown);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = () => {
      setAdminDropdown(false);
    };

    if (adminDropdown) {
      document.addEventListener('click', handleClickOutside);
    }

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [adminDropdown]);

  return (
    <nav className="fixed w-full bg-white dark:bg-black shadow-md z-50 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <Link
          href="/"
          className="text-xl font-bold text-gray-900 dark:text-white hover:text-blue-500 dark:hover:text-indigo-400 transition"
        >
          Jerry Nwachi
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-6 text-gray-700 dark:text-white font-medium">
          <Link 
            href="/"
            className={`hover:text-blue-500 dark:hover:text-indigo-400 transition ${
              router.pathname === '/' ? 'text-blue-500 dark:text-indigo-400' : ''
            }`}
          >
            Home
          </Link>
          
          <Link 
            href="/blogs"
            className={`hover:text-blue-500 dark:hover:text-indigo-400 transition ${
              router.pathname.startsWith('/blogs') ? 'text-blue-500 dark:text-indigo-400' : ''
            }`}
          >
            Blog
          </Link>
          
          <Link 
            href="/#projects"
            className="hover:text-blue-500 dark:hover:text-indigo-400 transition"
          >
            Projects
          </Link>
          
          <Link 
            href="/skills"
            className={`hover:text-blue-500 dark:hover:text-indigo-400 transition ${
              router.pathname === '/skills' ? 'text-blue-500 dark:text-indigo-400' : ''
            }`}
          >
            Skills
          </Link>
          
          <Link 
            href="/about"
            className={`hover:text-blue-500 dark:hover:text-indigo-400 transition ${
              router.pathname === '/about' ? 'text-blue-500 dark:text-indigo-400' : ''
            }`}
          >
            About
          </Link>

          {/* Admin Section */}
          <div className="relative">
            {auth && admin ? (
              <div className="relative">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleAdminDropdown();
                  }}
                  className="flex items-center focus:outline-none hover:text-blue-500 dark:hover:text-indigo-400 transition"
                >
                  <FaUser className="mr-1" /> {user?.userName} <FaCaretDown className="ml-1" />
                </button>
                
                {adminDropdown && (
                  <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-gray-800 rounded-md shadow-lg py-1 z-50 border dark:border-gray-700">
                    <Link
                      href="/admin"
                      className="flex items-center px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition"
                      onClick={() => setAdminDropdown(false)}
                    >
                      <FaUser className="mr-2" /> Dashboard
                    </Link>
                    
                    <Link
                      href="/admin/blogs"
                      className="flex items-center px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition"
                      onClick={() => setAdminDropdown(false)}
                    >
                      <FaBlog className="mr-2" /> Manage Blogs
                    </Link>
                    
                    <Link
                      href="/admin/projects"
                      className="flex items-center px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 transition"
                      onClick={() => setAdminDropdown(false)}
                    >
                      <FaProjectDiagram className="mr-2" /> Manage Projects
                    </Link>
                    
                    <div className="border-t dark:border-gray-600 my-1"></div>
                    
                    <button 
                      onClick={handleLogout} 
                      className="flex items-center w-full px-4 py-2 text-sm text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700 transition"
                    >
                      <FaSignOutAlt className="mr-2" /> Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link
                href="/login"
                className="hover:text-blue-500 dark:hover:text-indigo-400 transition"
              >
                Admin Login
              </Link>
            )}
          </div>

          {/* Theme Toggle */}
          {mounted && (
            <button
              onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
              className="ml-4 p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              aria-label="Toggle Theme"
            >
              {theme === 'light' ? <MdDarkMode size={20} /> : <MdLightMode size={20} />}
            </button>
          )}
        </div>

        {/* Mobile Hamburger */}
        <div className="md:hidden flex items-center space-x-2">
          {mounted && (
            <button
              onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
              className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              aria-label="Toggle Theme"
            >
              {theme === 'light' ? <MdDarkMode size={20} /> : <MdLightMode size={20} />}
            </button>
          )}
          
          <button 
            onClick={toggleMenu} 
            aria-label="Toggle menu"
            className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 transition"
          >
            {isOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white dark:bg-black border-t dark:border-gray-800 px-4 pb-4 flex flex-col space-y-4 text-gray-800 dark:text-white">
          <Link 
            href="/" 
            onClick={closeMenu}
            className={`py-2 ${router.pathname === '/' ? 'text-blue-500 dark:text-indigo-400 font-semibold' : ''}`}
          >
            Home
          </Link>
          
          <Link 
            href="/blogs" 
            onClick={closeMenu}
            className={`py-2 ${router.pathname.startsWith('/blogs') ? 'text-blue-500 dark:text-indigo-400 font-semibold' : ''}`}
          >
            Blog
          </Link>
          
          <Link 
            href="/#projects" 
            onClick={closeMenu}
            className="py-2"
          >
            Projects
          </Link>
          
          <Link 
            href="/skills" 
            onClick={closeMenu}
            className={`py-2 ${router.pathname === '/skills' ? 'text-blue-500 dark:text-indigo-400 font-semibold' : ''}`}
          >
            Skills
          </Link>
          
          <Link 
            href="/about" 
            onClick={closeMenu}
            className={`py-2 ${router.pathname === '/about' ? 'text-blue-500 dark:text-indigo-400 font-semibold' : ''}`}
          >
            About
          </Link>

          {/* Mobile Admin Section */}
          <div className="border-t dark:border-gray-700 pt-4">
            {auth && admin ? (
              <>
                <div className="flex items-center mb-3 text-sm text-gray-600 dark:text-gray-400">
                  <FaUser className="mr-2" /> Welcome, {user?.userName}
                </div>
                
                <Link 
                  href="/admin" 
                  onClick={closeMenu} 
                  className="flex items-center py-2 hover:text-blue-500 dark:hover:text-indigo-400 transition"
                >
                  <FaUser className="mr-2" /> Dashboard
                </Link>
                
                <Link 
                  href="/admin/blogs" 
                  onClick={closeMenu} 
                  className="flex items-center py-2 hover:text-blue-500 dark:hover:text-indigo-400 transition"
                >
                  <FaBlog className="mr-2" /> Manage Blogs
                </Link>
                
                <Link 
                  href="/admin/projects" 
                  onClick={closeMenu} 
                  className="flex items-center py-2 hover:text-blue-500 dark:hover:text-indigo-400 transition"
                >
                  <FaProjectDiagram className="mr-2" /> Manage Projects
                </Link>
                
                <button 
                  onClick={handleLogout} 
                  className="flex items-center py-2 text-red-500 hover:text-red-700 transition w-full text-left"
                >
                  <FaSignOutAlt className="mr-2" /> Logout
                </button>
              </>
            ) : (
              <Link 
                href="/login" 
                onClick={closeMenu} 
                className="py-2 font-semibold text-blue-500 dark:text-indigo-400"
              >
                Admin Login
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}