// components/AdminLayout.js
import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { isAuthenticated, isAdmin } from '../Lib/auth';
import Navbar from './Navbar';

export default function AdminLayout({ children }) {
  const router = useRouter();

  useEffect(() => {
    // Check if user is authenticated and admin
    if (!isAuthenticated() || !isAdmin()) {
      router.push('/login');
    }
  }, [router]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />
      <div className="pt-20">
        {children}
      </div>
    </div>
  );
}